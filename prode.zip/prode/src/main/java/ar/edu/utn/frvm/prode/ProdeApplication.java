package ar.edu.utn.frvm.prode;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProdeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProdeApplication.class, args);
	}

}
